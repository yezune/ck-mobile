package kr.actus.ckck.util;

import android.content.Context;

public class GetLocation {
Context context;

	public GetLocation(Context context){
		this.context = context;
		
	}
	
	
	
}
